//
//  SecondViewController.swift
//  Music
//
//  Created by Gabriel Chapel on 1/25/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var musicPicker: UIPickerView!
    @IBOutlet weak var choiceLabel: UILabel!
    
    let artistComponent = 0
    let albumComponent = 1
    
    var artistAlbums = [String: [String]]()
    var artists = [String]()
    var albums = [String]()
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == artistComponent{
            return artists.count
        }else{
            return albums.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == artistComponent{
            return artists[row]
        }else{
            return albums[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        // checks which component was picked
        if component == artistComponent{
            let selectedArtist = artists[row] // gets the selected artist
            albums = artistAlbums[selectedArtist]! // gets the albums for the selected artist
            musicPicker.reloadComponent(albumComponent) // reload the album component
            musicPicker.selectRow(0, inComponent: albumComponent, animated: true) // set the album component back to 0
        }
        let artistrow = pickerView.selectedRow(inComponent: artistComponent) // gets the selected row for the artist
        let albumrow = pickerView.selectedRow(inComponent: albumComponent) // gets selected row for album
        choiceLabel.text = "You like \(albums[albumrow]) by \(artists[artistrow])"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // URL for our plist
        if let pathURL = Bundle.main.url(forResource: "artistalbums", withExtension: "plist") {
            // creates a property list decoder object
            let plistdecoder = PropertyListDecoder()
            do{
                let data = try Data(contentsOf: pathURL)
                // decodes the plist
                artistAlbums = try plistdecoder.decode([String: [String]].self, from: data)
                artists = Array(artistAlbums.keys)
                albums = artistAlbums[artists[0]]! as [String]
            } catch{
                // handle error
                print(error)
            }
        }
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

