//
//  FourthViewController.swift
//  Music
//
//  Created by Gabriel Chapel on 1/30/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit
import AVFoundation

class FourthViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {

    @IBOutlet weak var recordAudio: UIButton!
    @IBOutlet weak var stopAudio: UIButton!
    @IBOutlet weak var playAudio: UIButton!
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?
    let fileName = "audio.m4a"
    
    @IBAction func recordButton(_ sender: UIButton) {
        // if not already recording, start recording
        if audioRecorder?.isRecording == false{
            playAudio.isEnabled = false
            stopAudio.isEnabled = true
            audioRecorder?.delegate = self
            audioRecorder?.record()
            recordAudio.setImage(UIImage(named: "recording"), for: .normal)
        }
    }
    @IBAction func stopButton(_ sender: Any) {
        stopAudio.isEnabled = false
        playAudio.isEnabled = true
        recordAudio.isEnabled = true
        // stop recording or playing
        if audioRecorder?.isRecording == true {
            audioRecorder?.stop()
            recordAudio.setImage(UIImage(named: "notRecording"), for: .normal)
        }else {
            audioPlayer?.stop()
            playAudio.setTitle("Play", for: .normal)
        }
    }
    @IBAction func playButton(_ sender: UIButton) {
        // if not recording play audio file
        if audioRecorder?.isRecording == false {
            stopAudio.isEnabled = true
            recordAudio.isEnabled = false
            playAudio.isEnabled = true
            if audioPlayer?.isPlaying == false || audioPlayer?.isPlaying == nil{
                do{
                    try audioPlayer = AVAudioPlayer(contentsOf: (audioRecorder?.url)!)
                    audioPlayer!.delegate = self
                    audioPlayer!.prepareToPlay() // preloads buffers for playback
                    audioPlayer!.play() // plays audio file
                    playAudio.setTitle("Pause", for: .normal)
                } catch let error as NSError {
                    print("audioPlayer error: \(error.localizedDescription)")
                }
            } else{
                playAudio.isEnabled = true
                stopAudio.isEnabled = true
                recordAudio.isEnabled = false
                audioPlayer!.pause() // pauses audio file
                playAudio.setTitle("Play", for: .normal)
            }
        }
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        recordAudio.isEnabled = true
        stopAudio.isEnabled = false
        playAudio.setTitle("Play", for: .normal)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //disable buttons since no audio has been recorded
        playAudio.isEnabled = false;
        stopAudio.isEnabled = false;
        
        //get path for audio file
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0] // documents directory
        print(docDir)
        let audioFileURL = docDir.appendingPathComponent(fileName)
        print(audioFileURL)
        
        //the shared audio session instance
        let audioSession = AVAudioSession.sharedInstance()
        do {
            //sets the category for recording and playback of audio
            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
        } catch {
            print("audio session error: \(error.localizedDescription)")
        }
        
        //recorder settings
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC), //specifies audio code
            AVSampleRateKey: 12000, //sample rate in hertz
            AVNumberOfChannelsKey: 1, //number of channels
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue //audio bit rate
        ]
        
        do{
            //create the AVAudioRecorder instance
            audioRecorder = try AVAudioRecorder(url: audioFileURL, settings: settings)
            audioRecorder?.prepareToRecord()
            print("audio recorder ready")
        } catch{
            print("audio recorder error: \(error.localizedDescription)")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
