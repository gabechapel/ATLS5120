package com.example.gabrielchapel.concertlist;

import android.app.Application;

import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * Created by gabrielchapel on 4/20/18.
 */

public class ConcertListApplication extends Application{
    @Override public void onCreate(){
        super.onCreate();
        //initialize Realm
        Realm.init(this);
        //define configuration for realm
        RealmConfiguration realmConfig = new RealmConfiguration.Builder().build();
        //set default realm config
        Realm.setDefaultConfiguration(realmConfig);
    }
}
