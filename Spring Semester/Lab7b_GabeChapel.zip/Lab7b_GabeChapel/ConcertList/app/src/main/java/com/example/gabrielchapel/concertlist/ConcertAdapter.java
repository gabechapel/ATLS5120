package com.example.gabrielchapel.concertlist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.TextView;

import io.realm.OrderedRealmCollection;
import io.realm.RealmBaseAdapter;

/**
 * Created by gabrielchapel on 4/23/18.
 */

public class ConcertAdapter extends RealmBaseAdapter<Concert> implements ListAdapter {

    private ConcertListActivity activity;

    private static class ViewHolder{
        TextView bandName;
        TextView venueName;
        CheckBox hasSeen;
    }

    ConcertAdapter(ConcertListActivity activity, OrderedRealmCollection<Concert> data){
        super(data);
        this.activity = activity;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolder viewHolder;

        if(convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.concert_list_row, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.bandName = (TextView) convertView.findViewById(R.id.bandTextView);
            viewHolder.venueName = (TextView) convertView.findViewById(R.id.venueTextView);
            viewHolder.hasSeen = (CheckBox) convertView.findViewById(R.id.checkBox);
            viewHolder.hasSeen.setOnClickListener(listener);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        if (adapterData != null) {
            Concert concert = adapterData.get(position);
            viewHolder.bandName.setText(concert.getBand_name());
            viewHolder.venueName.setText(concert.getVenue_name());
            viewHolder.hasSeen.setChecked(concert.hasSeen());
            viewHolder.hasSeen.setTag(position);
        }
        return convertView;
    }

    private View.OnClickListener listener = new View.OnClickListener(){
        @Override
        public void onClick(View view){
            int position = (Integer)view.getTag();
            if(adapterData != null){
                Concert concert = adapterData.get(position);
                activity.changeConcertSeen(concert.getId());
            }
        }
    };
}
