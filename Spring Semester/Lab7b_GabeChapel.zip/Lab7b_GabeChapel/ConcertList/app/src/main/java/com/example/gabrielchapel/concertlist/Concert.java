package com.example.gabrielchapel.concertlist;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

/**
 * Created by gabrielchapel on 4/20/18.
 */

public class Concert extends RealmObject {
    @Required
    @PrimaryKey
    private String id;
    private String band_name;
    private String venue_name;
    private boolean seen;

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getBand_name(){
        return band_name;
    }

    public void setBand_name(String concert){
        this.band_name = concert;
    }

    public String getVenue_name(){
        return venue_name;
    }

    public void setVenue_name(String venue){
        this.venue_name = venue;
    }

    public boolean hasSeen(){
        return seen;
    }

    public void setSeen(boolean done){
        this.seen = done;
    }
}
