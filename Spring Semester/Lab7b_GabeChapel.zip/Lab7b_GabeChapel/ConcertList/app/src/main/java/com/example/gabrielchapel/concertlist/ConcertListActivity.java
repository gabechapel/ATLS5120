package com.example.gabrielchapel.concertlist;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.UUID;

import io.realm.Realm;
import io.realm.RealmResults;

public class ConcertListActivity extends AppCompatActivity {

    private Realm realm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_concert_list);

        //get realm instance
        realm = Realm.getDefaultInstance();

        //get all saved Concert objects
        RealmResults<Concert>concerts = realm.where(Concert.class).findAll();

        final ConcertAdapter adapter = new ConcertAdapter(this, concerts);

        ListView listView = (ListView)findViewById(R.id.concert_list);

        //set RealmBaseAdapter to listview
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //create vertical linear layout to hold edit texts
                LinearLayout layout = new LinearLayout(ConcertListActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                final Concert concert = (Concert)adapterView.getAdapter().getItem(i);

                //create edit texts and add to layout
                final EditText bandEditText = new EditText(ConcertListActivity.this);
                bandEditText.setText(concert.getBand_name());
                layout.addView(bandEditText);
                final EditText venueEditText = new EditText(ConcertListActivity.this);
                venueEditText.setText(concert.getVenue_name());
                layout.addView(venueEditText);

                AlertDialog.Builder dialog = new AlertDialog.Builder(ConcertListActivity.this);
                dialog.setTitle("Edit Concert");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // get updated band and venue names
                        final String updatedBandName = bandEditText.getText().toString();
                        final String updatedVenueName = venueEditText.getText().toString();
                        if(!updatedBandName.isEmpty()){
                            changeConcert(concert.getId(), updatedBandName, updatedVenueName);
                        }
                    }
                });
                dialog.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //delete concert
                        deleteConcert(concert.getId());
                    }
                });
                dialog.create();
                dialog.show();
            }
        });

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //create vertical linear layout to hold edit texts
                LinearLayout layout = new LinearLayout(ConcertListActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                //create edit texts and add to layout
                final EditText bandEditText = new EditText(ConcertListActivity.this);
                bandEditText.setHint("Band name");
                layout.addView(bandEditText);
                final EditText venueEditText = new EditText(ConcertListActivity.this);
                venueEditText.setHint("Venue name");
                layout.addView(venueEditText);

                //create alert dialog
                AlertDialog.Builder dialog = new AlertDialog.Builder(ConcertListActivity.this);
                dialog.setTitle("Add Concert");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //get band name entered
                        final String newBandName = bandEditText.getText().toString();
                        final String newVenueName = venueEditText.getText().toString();

                        if(!newBandName.isEmpty()) {
                            //start realm write transaction
                            realm.executeTransactionAsync(new Realm.Transaction() {
                                @Override
                                public void execute(Realm realm) {
                                    //create realm object
                                    Concert newConcert = realm.createObject(Concert.class, UUID.randomUUID().toString());
                                    newConcert.setBand_name(newBandName);
                                    newConcert.setVenue_name(newVenueName);
                                }
                            });
                        }
                    }
                });
                dialog.setNegativeButton("Cancel", null);
                dialog.show();
            }
        });
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        //close Realm instance when Activity exits
        realm.close();
    }

    public void changeConcertSeen(final String concertId){
        realm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Concert concert = realm.where(Concert.class).equalTo("id", concertId).findFirst();
                concert.setSeen(!concert.hasSeen());
            }
        });
    }

    private void changeConcert(final String concertID, final String band_name, final String venu_name){
        realm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Concert concert = realm.where(Concert.class).equalTo("id", concertID).findFirst();
                concert.setBand_name(band_name);
                concert.setVenue_name(venu_name);
            }
        });
    }

    private void deleteConcert(final String concertId){
        realm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.where(Concert.class).equalTo("id", concertId).findFirst().deleteFromRealm();;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_concert_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
