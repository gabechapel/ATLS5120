package com.example.gabrielchapel.superhero;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HeroDetailFragment extends Fragment implements View.OnClickListener {
    private ArrayAdapter<String>adapter;
    private long universeId;

    public void setUniverse(long id){
        this.universeId = id;
    }

    //create interface
    interface ButtonClickeListener{
        void addheroclicked(View view);
    }

    //create listener
    private ButtonClickeListener listener;

    @Override public void onAttach(Context context){
        super.onAttach(context);
        //attach context to listener
        listener = (ButtonClickeListener)context;
    }

    @Override public void onClick(View view){
        if(listener != null){
            listener.addheroclicked(view);
        }
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        //cast ContextMenu.ContextMenuInfo to AdapterView.AdapterContextMenuInfo since we use an adapter
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo)menuInfo;
        // get hero name that was pressed
        String heroname = adapter.getItem(adapterContextMenuInfo.position);
        //set menu title
        menu.setHeaderTitle("Delete" + heroname);
        // add choices to menu
        menu.add(1,1,1,"Yes");
        menu.add(2,2,2,"No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        // get item id
        int itemId = item.getItemId();
        if(itemId == 1){//item was pressed
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
            //remove hero
            Hero.heroes[(int)universeId].getSuperheroes().remove(info.position);
            //refresh listView
            HeroDetailFragment.this.adapter.notifyDataSetChanged();
        }
        return true;
    }

    @Override public void onStart(){
        super.onStart();

        View view = getView();
        ListView listHeroes = (ListView)view.findViewById(R.id.herolistView);

        //get hero data
        ArrayList<String>herolist = new ArrayList<String>();
        herolist = Hero.heroes[(int)universeId].getSuperheroes();

        //set array adapter
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, herolist);

        //bind array adapter to list view
        listHeroes.setAdapter(adapter);

        Button addHeroButton = (Button)view.findViewById(R.id.addHeroButton);
        addHeroButton.setOnClickListener(this);

        //register context menu
        registerForContextMenu(listHeroes);
    }

    public void addhero(){
        //create alert dialog
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        //create edit text
        final EditText edittext = new EditText(getActivity());
        //add edit text to dialog
        dialog.setView(edittext);
        //set dialog title
        dialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //get hero name entered
                String heroName = edittext.getText().toString();
                if(!heroName.isEmpty()){
                    //add hero
                    Hero.heroes[(int)universeId].getSuperheroes().add(heroName);
                    //refresh the list view
                    HeroDetailFragment.this.adapter.notifyDataSetChanged();
                }
            }
        });
        //sets cancel action
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //cancel
            }
        });
        dialog.show();
    }


    public HeroDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(savedInstanceState != null) {
            universeId = savedInstanceState.getLong("universeID");
        }
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_hero_detail, container, false);
    }

    @Override public void onSaveInstanceState(Bundle savedInstanceState){
        savedInstanceState.putLong("universeID", universeId);
    }

}
