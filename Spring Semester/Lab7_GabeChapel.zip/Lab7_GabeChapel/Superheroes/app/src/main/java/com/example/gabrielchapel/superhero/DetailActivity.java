package com.example.gabrielchapel.superhero;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class DetailActivity extends Activity implements HeroDetailFragment.ButtonClickeListener {

    @Override public void addheroclicked(View view){
        HeroDetailFragment fragment = (HeroDetailFragment)getFragmentManager().findFragmentById(R.id.fragment_container);
        fragment.addhero();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //get reference to hero detail fragment
        HeroDetailFragment heroDetailFragment = (HeroDetailFragment)getFragmentManager().findFragmentById(R.id.fragment_container);
        //get id passed in intent
        int universeId = (int)getIntent().getExtras().get("id");
        //pass universe id to fragment
        heroDetailFragment.setUniverse(universeId);
    }
}
