package com.example.gabrielchapel.recipes;

/**
 * Created by gabrielchapel on 5/7/18.
 */

public class RecipeItem {
    private String id;
    private String name;
    private String url;

    public RecipeItem(){
    }

    public RecipeItem (String newid, String newName, String newURL){
        id = newid;
        name = newName;
        url = newURL;
    }

    public String getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String geturl(){
        return url;
    }
    public String toString(){
        return this.name;
    }
}
