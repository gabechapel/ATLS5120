package com.example.gabrielchapel.spring;

/**
 * Created by gabrielchapel on 3/22/18.
 */

public class Bulb {
    private String name;
    private int imageResourceID;

    //constructor
    private Bulb(String newname, int newID){
        this.name = newname;
        this.imageResourceID = newID;
    }

    public static final Bulb[] tulips = {
            new Bulb("Apeldoorn Elite", R.drawable.apeldoorn),
            new Bulb("Banja Luka", R.drawable.banjaluka),
            new Bulb("Burning Heart", R.drawable.burningheart),
            new Bulb("Cape Cod", R.drawable.capecod),
            new Bulb("Daydream", R.drawable.daydream)
    };

    public static final Bulb[] daffodils = {
            new Bulb("Bella Vista", R.drawable.bellavista),
            new Bulb("Big Gun", R.drawable.biggun),
            new Bulb("Full House", R.drawable.fullhouse),
            new Bulb("Ice Follies", R.drawable.icefollies),
            new Bulb("Yellow Hoop", R.drawable.yellowhoop)
    };

    public static final Bulb[] iris = {
            new Bulb("Blazing Sunrise", R.drawable.blazingsunrise),
            new Bulb("October Sun", R.drawable.octobersun),
            new Bulb("Purple Night Sky", R.drawable.purplenightsky),
            new Bulb("Temper Tantrum", R.drawable.tempertantrum),
            new Bulb("Victoria Falls", R.drawable.victoriafalls)
    };

    public String getName(){
        return name;
    }

    public int getImageResourceID(){
        return imageResourceID;
    }

    public String toString(){
        return this.name;
    }
}
