package com.example.gabrielchapel.looper;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class RecordMainActivity extends AppCompatActivity {

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private boolean permissionToRecord = false;
    private String[] permissions = {Manifest.permission.RECORD_AUDIO};


    private Button recordButton, playButton;
    private MediaRecorder audioRecorder;
    private MediaPlayer mediaPlayer;
    private String outputFile;

    //Permission code from https://developer.android.com/guide/topics/media/mediarecorder.html
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecord) finish();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_main);

        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        recordButton = (Button) findViewById(R.id.recordButton);
        playButton = (Button) findViewById(R.id.playButton);

        //Set up output file
        outputFile = getExternalCacheDir().getAbsolutePath() + "/recording.3gp";

        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recordButton.getText().toString().equalsIgnoreCase("Record")) { //Begin recording
                    audioRecorder = new MediaRecorder();
                    audioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC); //Use microphone
                    audioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP); //https://developer.android.com/guide/topics/media/media-formats.html
                    audioRecorder.setOutputFile(outputFile);
                    audioRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                    recordButton.setText("Stop");
                    playButton.setEnabled(false);
                    try {
                        audioRecorder.prepare();
                    } catch (IOException ioError) {
                        Log.e("PrepareError", "onClick: Fail to Prepare");
                    }
                    audioRecorder.start();

                } else if (recordButton.getText().toString().equalsIgnoreCase("Stop")) { //Stop recording
                    recordButton.setText("Record");
                    audioRecorder.stop();
                    audioRecorder.release();
                    audioRecorder = null;
                    playButton.setEnabled(true);
                }
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playButton.getText().toString().equalsIgnoreCase("Play")) { //Begin playback
                    mediaPlayer = new MediaPlayer();
                    playButton.setText("Stop");
                    recordButton.setEnabled(false);
                    try {
                        mediaPlayer.setDataSource(outputFile);
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                Log.e("Completion", "onClick: First Loop Completed");
                                loopAudio();
                            }
                        });
                    } catch (IOException ioError) {
                        Log.e("PlayError", "onClick: Play Prepare Failure");
                    }
                } else if (playButton.getText().toString().equalsIgnoreCase("Stop")) { //Stop playback
                    playButton.setText("Play");
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                    recordButton.setEnabled(true);
                }

            }
        });
    }

    private void loopAudio() {
        try {
            Log.e("Loop", "onClick: Got to Loop");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(outputFile);
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    loopAudio();
                }
            });
        } catch (Exception error) {

        }
    }
}
