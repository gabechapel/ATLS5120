package com.example.gabrielchapel.looper;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class SavedRecordingsActivity extends ListActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent i = getIntent();

        Log.e("TEST", "TEST");
        ArrayList<String> test = new ArrayList<String>();
        test = i.getStringArrayListExtra("FileNames");

        Log.e("TEST", String.valueOf(test));

        List<String> fileName = i.getStringArrayListExtra("FileNames");

        ListView recordings = getListView();
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fileName);

        recordings.setAdapter(listAdapter);

    }
}
