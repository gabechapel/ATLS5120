package com.example.gabrielchapel.looper;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class RecordMainActivity extends AppCompatActivity {

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private boolean permissionToRecord = false;
    private String[] permissions = {Manifest.permission.RECORD_AUDIO};


    private Button recordButton1, recordButton2, playButton, saveButton, savedRecordings;
    TextView volumeLabel1;
    TextView volumeLabel2;
    SeekBar volumeChange1;
    SeekBar volumeChange2;
    int maxVolume = 100;
    float volume1 = 50;
    float volume2 = 50;
    private MediaRecorder audioRecorder1;
    private MediaRecorder audioRecorder2;
    private MediaPlayer mediaPlayer1;
    private MediaPlayer mediaPlayer2;
    private String outputFile1;
    private String outputFile2;
    ArrayList<ArrayList> recordedFiles = new ArrayList<ArrayList>();
    ArrayList<String> playFiles = new ArrayList<String>();
    ArrayList<String> fileNames = new ArrayList<String>();

    //Permission code from https://developer.android.com/guide/topics/media/mediarecorder.html
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecord) finish();
    }


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_main);

        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        // AudioRecorder code from http://mobiledevhub.com/2017/12/25/android-recording-audio/ and
        // https://developer.android.com/guide/topics/media/mediarecorder.html and
        // https://www.youtube.com/watch?v=ZM_jAnx57Nk
        recordButton1 = (Button) findViewById(R.id.recordButton1);
        recordButton2 = (Button) findViewById(R.id.recordButton2);
        playButton = (Button) findViewById(R.id.playButton);
        saveButton = (Button)findViewById(R.id.saveButton);
        savedRecordings = (Button)findViewById(R.id.savedRecordings);

        volumeLabel1 = (TextView)findViewById(R.id.volumeLabel1);
        volumeLabel2 = (TextView)findViewById(R.id.volumeLabel2);

        //Set up seekbar
        volumeChange1 = (SeekBar)findViewById(R.id.volumeChange1);
        volumeChange2 = (SeekBar)findViewById(R.id.volumeChange2);
        volumeChange1.setMax(maxVolume);
        volumeChange2.setMax(maxVolume);

        recordButton2.setEnabled(false);
        playButton.setEnabled(false);
        saveButton.setEnabled(false);

        volumeChange1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volumeLabel1.setText("Volume: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        volumeChange2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volumeLabel2.setText("Volume: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //Set up output file
        outputFile1 = getExternalCacheDir().getAbsolutePath() + "/recording1.3gp";
        outputFile2 = getExternalCacheDir().getAbsolutePath() + "/recording2.3gp";

        // First track recording
        recordButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recordButton1.getText().toString().equalsIgnoreCase("Record")) { //Begin recording
                    audioRecorder1 = new MediaRecorder();
                    audioRecorder1.setAudioSource(MediaRecorder.AudioSource.MIC); //Use microphone
                    audioRecorder1.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP); //https://developer.android.com/guide/topics/media/media-formats.html
                    audioRecorder1.setOutputFile(outputFile1);
                    Log.e("FilePath", outputFile1);
                    audioRecorder1.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                    recordButton1.setBackgroundResource(R.drawable.stopbutton);
                    recordButton1.setText("Stop");
                    try {
                        audioRecorder1.prepare();
                    } catch (IOException ioError) {
                        Log.e("PrepareError", "onClick: Fail to Prepare");
                    }
                    audioRecorder1.start();

                } else if (recordButton1.getText().toString().equalsIgnoreCase("Stop")) { //Stop recording
                    recordButton1.setBackgroundResource(R.drawable.recordbutton);
                    recordButton1.setText("Record");
                    audioRecorder1.stop();
                    audioRecorder1.release();
                    audioRecorder1 = null;
                    playButton.setEnabled(true);
                    recordButton2.setEnabled(true);
                    saveButton.setEnabled(true);
                }
            }
        });

        // First track recording
        recordButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recordButton2.getText().toString().equalsIgnoreCase("Record")) { //Begin recording
                    playAudio();
                    recordButton2.setEnabled(true);
                    audioRecorder2 = new MediaRecorder();
                    audioRecorder2.setAudioSource(MediaRecorder.AudioSource.MIC); //Use microphone
                    audioRecorder2.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP); //https://developer.android.com/guide/topics/media/media-formats.html
                    audioRecorder2.setOutputFile(outputFile2);
                    Log.e("FilePath", outputFile2);
                    audioRecorder2.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                    recordButton2.setBackgroundResource(R.drawable.stopbutton);
                    recordButton2.setText("Stop");
                    try {
                        audioRecorder2.prepare();
                    } catch (IOException ioError) {
                        Log.e("PrepareError", "onClick: Fail to Prepare");
                    }
                    audioRecorder2.start();

                } else if (recordButton2.getText().toString().equalsIgnoreCase("Stop")) { //Stop recording
                    stopAudio();
                    recordButton2.setBackgroundResource(R.drawable.recordbutton);
                    recordButton2.setText("Record");
                    audioRecorder2.stop();
                    audioRecorder2.release();
                    audioRecorder2 = null;
                    recordButton1.setEnabled(true);
                }
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (playButton.getText().toString().equalsIgnoreCase("Play")) { //Begin playback
                    playAudio();

                } else if (playButton.getText().toString().equalsIgnoreCase("Stop")) { //Stop playback
                    stopAudio();
                    recordButton1.setEnabled(true);
                    recordButton2.setEnabled(true);
                }

            }
        });

        savedRecordings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecordMainActivity.this, SavedRecordingsActivity.class);
                intent.putExtra("Recordings", recordedFiles);
                intent.putExtra("FileNames", fileNames);
                Log.e("Names", String.valueOf(fileNames.size()));
                Log.e("Names", String.valueOf(fileNames));
                startActivity(intent);


            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playFiles.addAll(Arrays.asList(outputFile1, outputFile2));
                recordedFiles.add(0, playFiles);
                fileNames.add("Recording # " + recordedFiles.size());
            }
        });
    }

    private void playAudio(){
        mediaPlayer1 = new MediaPlayer();
        mediaPlayer2 = new MediaPlayer();
        playButton.setBackgroundResource(R.drawable.stopplayingbutton);
        playButton.setText("Stop");
        recordButton1.setEnabled(false);
        recordButton2.setEnabled(false);
        // Find volume specified by seek bar, expressed as log. From https://stackoverflow.com/questions/5215459/android-mediaplayer-setvolume-function
        volume1 = (float)(1-(Math.log(maxVolume - volumeChange1.getProgress())/Math.log(maxVolume)));
        volume2 = (float)(1-(Math.log(maxVolume - volumeChange2.getProgress())/Math.log(maxVolume)));

        try {
            //Try playing first track
            mediaPlayer1.setDataSource(outputFile1);
            mediaPlayer1.prepare();
            mediaPlayer1.setVolume(volume1, volume1);
//                        mediaPlayer1.setLooping(true);
            mediaPlayer1.start();
            // Change volume when seekbar changes
            volumeChange1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    volume1 = (float)(1-(Math.log(maxVolume - progress)/Math.log(maxVolume)));
                    try {
                        mediaPlayer1.setVolume(volume1, volume1);
                    } catch (Exception error){

                    }
                    volumeLabel1.setText("Volume: " + progress);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
//
            // Wait until first track starts over
            mediaPlayer1.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    Log.e("Completion", "onClick: First Loop Completed");
                    loopAudio1();
                }
            });
        } catch (IOException ioError) {
            Log.e("PlayError", "onClick: Play 1 Prepare Failure");
        }

        try{
            // Try playing second track
            mediaPlayer2.setDataSource(outputFile2);
            mediaPlayer2.prepare();
            mediaPlayer2.setVolume(volume2, volume2);
            mediaPlayer2.start();
            // Change volume when seekbar changes
            volumeChange2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    volume2 = (float)(1-(Math.log(maxVolume - progress)/Math.log(maxVolume)));
                    try {
                        mediaPlayer2.setVolume(volume2, volume2);
                    } catch (Exception error){

                    }
                    volumeLabel2.setText("Volume: " + progress);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        } catch(IOException ioError) {
            Log.e("PlayError", "onClick: Play 2 Prepare Failure");
        }
    }


    private void stopAudio(){
        playButton.setBackgroundResource(R.drawable.playbutton);
        playButton.setText("Play");
        mediaPlayer1.stop();
        mediaPlayer1.reset();
        mediaPlayer1.release();
        mediaPlayer1 = null;
        try{
            mediaPlayer2.stop();
            mediaPlayer2.reset();
            mediaPlayer2.release();
            mediaPlayer2 = null;
        } catch (Exception error){

        }
    }

    private void loopAudio1() {
        try {
            Log.e("Loop", "onClick: Got to Loop 1");
            mediaPlayer1 = new MediaPlayer();
            mediaPlayer1.setDataSource(outputFile1);
            mediaPlayer1.prepare();
            mediaPlayer1.setVolume(volume1, volume1);
            mediaPlayer1.start();
        } catch (Exception error) {
            Log.e("LoopError", "onClick: Loop 1 Prepare Failure");
        }
        try {
            Log.e("Loop", "onClick: Got to Loop 2");
            mediaPlayer2 = new MediaPlayer();
            mediaPlayer2.setDataSource(outputFile2);
            mediaPlayer2.prepare();
            mediaPlayer2.setVolume(volume2, volume2);
            mediaPlayer2.start();
        } catch (Exception error) {
            Log.e("LoopError", "onClick: Loop 2 Prepare Failure");
        }

        mediaPlayer1.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                loopAudio1();
            }
        });
    }

}
