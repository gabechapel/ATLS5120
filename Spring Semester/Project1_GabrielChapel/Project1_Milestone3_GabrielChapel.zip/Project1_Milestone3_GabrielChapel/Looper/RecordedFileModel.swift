//
//  RecordedFileModel.swift
//  Looper
//
//  Created by Gabriel Chapel on 3/11/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit
import AVFoundation

class RecordedFileModel: NSObject {
    var savedURLs:[[URL]] = []
}
