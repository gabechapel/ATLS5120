//
//  TableViewController.swift
//  Looper
//
//  Created by Gabriel Chapel on 3/10/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit
import AVFoundation

class TableViewController: UITableViewController, AVAudioPlayerDelegate {
    var audioFiles = RecordedFileModel()
    var savedFiles:[[URL]] = []
    var audioPlayer:AVAudioPlayer?
    var audioPlayer2:AVAudioPlayer?
    var deviceTime:TimeInterval = 0.0
    var i = 1.0
    var ratio = 0.0
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        savedFiles = audioFiles.savedURLs
        tableView.reloadData()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background")!)
        let tbvc = self.tabBarController as! FileTabBarController
        audioFiles = tbvc.files

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

//    override func numberOfSections(in tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 0
//    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return audioFiles.savedURLs.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "Play Recording \(indexPath.row + 1)"
        cell.backgroundColor = UIColor(patternImage: UIImage(named: "background")!)

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if audioPlayer?.isPlaying == false || audioPlayer?.isPlaying == nil {
            do
            {
                try audioPlayer = AVAudioPlayer(contentsOf: savedFiles[indexPath.row][0])
                audioPlayer!.numberOfLoops = -1
                audioPlayer!.delegate = self
                audioPlayer!.prepareToPlay()
                audioPlayer!.play()
                try audioPlayer2 = AVAudioPlayer(contentsOf: savedFiles[indexPath.row][1])
                audioPlayer2!.numberOfLoops = 0
                audioPlayer2!.delegate = self
                self.ratio = audioPlayer2!.duration/audioPlayer!.duration
                self.ratio = self.ratio.rounded(.up)
                self.i = self.ratio.rounded(.up)
                audioPlayer2!.prepareToPlay()
                audioPlayer!.play()
                self.deviceTime = (audioPlayer?.deviceCurrentTime)!
                audioPlayer2!.play()
                audioPlayer!.currentTime = 0.0
                Timer.scheduledTimer(timeInterval: 0.0001, target: self, selector: (#selector(self.loopSecondTrack)), userInfo: nil, repeats: true)
                tableView.cellForRow(at: indexPath)?.imageView?.image = UIImage(named: "pauseButton")
                tableView.cellForRow(at: indexPath)?.textLabel?.text = "Pause Recording \(indexPath.row + 1)"
            }catch let error as NSError {
                print("audioPlayer error: \(error.localizedDescription)")
            }
        }else{
            audioPlayer!.pause()
            audioPlayer2?.pause()
            tableView.cellForRow(at: indexPath)?.textLabel?.text = "Play Recording \(indexPath.row + 1)"
            tableView.cellForRow(at: indexPath)?.imageView?.image = UIImage(named: "playButton")
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    @objc func loopSecondTrack() {
        if audioPlayer?.isPlaying == true {
            let timeCheck = audioPlayer!.deviceCurrentTime - self.deviceTime
            if abs(timeCheck - ((self.i-1.0) * audioPlayer!.duration + audioPlayer2!.duration)) < 0.05 {
                audioPlayer2!.play(atTime: self.deviceTime + self.i*audioPlayer!.duration)
                print("will play loop ", i)
                self.i += self.ratio
            }
        }
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
