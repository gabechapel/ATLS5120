//
//  ViewController.swift
//  Looper
//
//  Created by Gabriel Chapel on 2/26/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var playButton2: UIButton!
    @IBOutlet weak var recordButton2: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var mute1: UIButton!
    @IBOutlet weak var mute2: UIButton!
    @IBOutlet weak var solo1: UIButton!
    @IBOutlet weak var solo2: UIButton!
    @IBOutlet weak var volume1: UISlider!
    @IBOutlet weak var volume2: UISlider!
    
    let kfilename = "data1.plist" //data persistance plist
    var audioFiles = RecordedFileModel()
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?
    var audioPlayer2: AVAudioPlayer?
    var audioRecorder2: AVAudioRecorder?
    
    let fileName = "audio.m4a"
    let fileName2 = "audio2.m4a"
    var deviceTime:TimeInterval = 0.0
    var i = 1.0
    var ratio = 0.0
    var numberOfRecords:Int = 1
    var savedRecordings:[[URL]] = []
    
    
    @IBAction func saveFiles(_ sender: UIButton) {
        if audioRecorder?.delegate != nil{  //if there is a recording
            numberOfRecords += 1
            UserDefaults.standard.set(numberOfRecords, forKey: "recordings")
            savedRecordings.append([(audioRecorder?.url)!, (audioRecorder2?.url)!])
            audioFiles.savedURLs = savedRecordings
            audioPlayer?.pause()
            playButton2.setImage(UIImage(named: "playButton"), for: .normal)
            viewDidLoad()
        }
    }
    @IBAction func muteButton1(_ sender: UIButton) {
        if mute1.isSelected == false{
            mute1.isSelected = true
            mute1.isHighlighted = true
            audioPlayer?.setVolume(0, fadeDuration: 0.01)
        }else{
            mute1.isSelected = false
            mute1.isHighlighted = false
            audioPlayer?.setVolume(volume1.value, fadeDuration: 0.01)
        }
    }
    @IBAction func muteButton2(_ sender: UIButton) {
        if mute2.isSelected == false{
            mute2.isSelected = true
            mute2.isHighlighted = true
            audioPlayer2?.setVolume(0, fadeDuration: 0.0)
        }else{
            mute2.isSelected = false
            mute2.isHighlighted = false
            audioPlayer2?.setVolume(volume1.value, fadeDuration: 0.0)
        }
    }
    @IBAction func soloButton1(_ sender: UIButton) {
        if solo1.isSelected == false{
            solo1.isSelected = true
            solo1.isHighlighted = true
            mute2.isSelected = true
            mute2.isHighlighted = true
            audioPlayer2?.setVolume(0, fadeDuration:0.0)
        }else{
            solo1.isSelected = false
            solo1.isHighlighted = false
            mute2.isSelected = false
            mute2.isHighlighted = true
            audioPlayer2?.setVolume(volume2.value, fadeDuration: 0.0)
        }
    }
    @IBAction func soloButton2(_ sender: UIButton) {
        if solo2.isSelected == false{
            solo2.isSelected = true
            solo2.isHighlighted = true
            mute1.isSelected = true
            mute1.isHighlighted = true
            audioPlayer?.setVolume(0, fadeDuration:0.0)
        }else{
            solo2.isSelected = false
            solo2.isHighlighted = false
            mute1.isSelected = false
            mute1.isHighlighted = true
            audioPlayer?.setVolume(volume1.value, fadeDuration: 0.0)
        }
    }
    @IBAction func changeVolume(_ sender: UISlider) {
        let volume = sender.value
        audioPlayer?.volume = volume
    }
    
    @IBAction func changeVolume2(_ sender: UISlider) {
        let volume2 = sender.value
        audioPlayer2?.volume = volume2
    }
    
    func playAudio() {
        recordButton.isEnabled = false
        if audioPlayer?.isPlaying == false || audioPlayer?.isPlaying == nil {
            do{
                try audioPlayer = AVAudioPlayer(contentsOf: (audioRecorder?.url)!)
                audioPlayer!.numberOfLoops = -1
                audioPlayer!.delegate = self
                audioPlayer!.prepareToPlay()
                playButton2.setImage(UIImage(named: "pauseButton"), for: .normal)
                if audioRecorder2?.delegate != nil {
                    try audioPlayer2 = AVAudioPlayer(contentsOf: (audioRecorder2?.url)!)
                    audioPlayer2!.numberOfLoops = 0
                    audioPlayer2!.delegate = self
                    self.ratio = audioPlayer2!.duration/audioPlayer!.duration
                    self.ratio = self.ratio.rounded(.up)
                    self.i = self.ratio.rounded(.up)
                    audioPlayer2!.prepareToPlay()
                    audioPlayer!.play()
                    if mute1.isSelected == false{
                        audioPlayer!.setVolume(volume1.value, fadeDuration: 0.0)
                    }else{
                        audioPlayer!.setVolume(0.0, fadeDuration: 0.0)
                    }
                    self.deviceTime = (audioPlayer?.deviceCurrentTime)!
                    audioPlayer2!.play()
                    if mute2.isSelected == false{
                        audioPlayer2!.setVolume(volume2.value, fadeDuration: 0.0)
                    }else{
                        audioPlayer2!.setVolume(0.0, fadeDuration: 0.0)
                    }
                    audioPlayer!.currentTime = 0.0
                    Timer.scheduledTimer(timeInterval: 0.0001, target: self, selector: (#selector(ViewController.loopSecondTrack)), userInfo: nil, repeats: true)
                } else {
                    audioPlayer!.play()
                    if mute1.isSelected == false{
                        audioPlayer!.setVolume(volume1.value, fadeDuration: 0.0)
                    }else{
                        audioPlayer!.setVolume(0.0, fadeDuration: 0.0)
                    }
                }
            } catch let error as NSError {
                print("audioPlayer error: \(error.localizedDescription)")
            }
        }else if audioPlayer?.isPlaying == true{
            recordButton.isEnabled = true
            audioPlayer!.pause()
            audioPlayer2?.pause()
            playButton2.setImage(UIImage(named: "playButton"), for: .normal)
        }
    }
    
    @IBAction func recordAudio(_ sender: UIButton) {
        recordButton.isHighlighted = false
            print("record audio 1")
            if audioRecorder?.isRecording == false{
                recordButton2.isEnabled = false
                audioRecorder?.delegate = self
                audioRecorder?.record()
                //animate the image transition, from https://stackoverflow.com/questions/36237668/transition-uibutton-image-from-one-image-to-another/36238417
                UIView.transition(with: sender, duration: 0.08, options: .transitionCrossDissolve, animations: {sender.setImage(UIImage(named: "stopButton"), for: .normal)}, completion: nil)
            }else if audioRecorder?.isRecording == true{
                playButton2.isEnabled = true
                recordButton2.isEnabled = true
                audioRecorder?.stop()
                UIView.transition(with: sender, duration: 0.08, options: .transitionCrossDissolve, animations: {sender.setImage(UIImage(named: "recordButton"), for: .normal)}, completion: nil)
            }
        }
    
    @IBAction func playAudio2(_ sender: UIButton) {
        print("play audio")
        self.playAudio()
    }
    
    @IBAction func recordAudio2(_ sender: UIButton) {
        print("record audio 2")
        if audioRecorder2?.isRecording == false{
            playButton2.isEnabled = false
            recordButton.isEnabled = false
            if audioPlayer?.isPlaying == false || audioPlayer?.isPlaying == nil{
                do{
                    try audioPlayer = AVAudioPlayer(contentsOf: (audioRecorder?.url)!)
                    audioPlayer!.numberOfLoops = -1
                    audioPlayer!.delegate = self
                    audioPlayer!.prepareToPlay()
                    audioPlayer!.play()
                    audioPlayer!.setVolume(volume1.value, fadeDuration: 0.0)
                    playButton2.setImage(UIImage(named: "pauseButton"), for: .normal)
                } catch let error as NSError {
                    print("audioPlayer error: \(error.localizedDescription)")
                }
            }
            audioRecorder2?.delegate = self
            audioRecorder2?.record()
            UIView.transition(with: sender, duration: 0.08, options: .transitionCrossDissolve, animations: {sender.setImage(UIImage(named: "stopButton"), for: .normal)}, completion: nil)
        }else if audioRecorder2?.isRecording == true{
            recordButton.isEnabled = true
            playButton2.isEnabled = true
            audioRecorder2?.stop()
            UIView.transition(with: sender, duration: 0.08, options: .transitionCrossDissolve, animations: {sender.setImage(UIImage(named: "recordButton"), for: .normal)}, completion: nil)
            audioPlayer!.stop()
            playButton2.setImage(UIImage(named: "playButton"), for: .normal)
        }
    }
    
    @objc func applicationWillResignActive(_ notification: NSNotification){
        let dirPath = FileManager.default.urls(for: .documentDirectory, in:.userDomainMask)
        let docDir = dirPath[0]
        print(docDir)
        
        let dataFileURL = docDir.appendingPathComponent(kfilename)
        print("persistent plist")
        print(dataFileURL)
        let plistencoder = PropertyListEncoder()
        plistencoder.outputFormat = .xml
        do{
            let data = try plistencoder.encode(savedRecordings)
            try data.write(to: dataFileURL)
        }catch {
            print(error)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background")!)
        volume1.setThumbImage(UIImage(named:"sliderWhite"), for: .normal)
        volume2.setThumbImage(UIImage(named:"sliderWhite"), for: .normal)
        
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0]
        
//        // Data Persistence
//        let pathURL:URL?
//        let dataFileURL = docDir.appendingPathComponent(kfilename)
//        print("dataFileURL", dataFileURL)
//
//        //if the data file exists, use it
//        if FileManager.default.fileExists(atPath: dataFileURL.path){
//            pathURL = dataFileURL
//            //creates a property list decoder object
//            let plistdecoder = PropertyListDecoder()
//            do {
//                let data = try Data(contentsOf: pathURL!)
//                //decodes the property list
//                savedRecordings = (try plistdecoder.decode([String:[String:String]].self, from: data) as? [[URL]])!
//                print(savedRecordings)
//            } catch {
//                // handle error
//                print(error)
//            }
//        }
        let app = UIApplication.shared
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.applicationWillResignActive(_:)), name: NSNotification.Name.UIApplicationWillResignActive, object: app)
        
        let tbvc = tabBarController as! FileTabBarController
        audioFiles = tbvc.files
        
        // Pull existing number of recordings if there are any
        if let number:Int = UserDefaults.standard.object(forKey: "recordings") as? Int {
            numberOfRecords = number
        }
        print(numberOfRecords)
        
        recordButton.isEnabled = true
        //disable button since no audio has been recorded
        playButton2.isEnabled = false
        recordButton2.isEnabled = false
        
        //get path for the audio file
        let audioFileURL = docDir.appendingPathComponent("\(numberOfRecords)_1.m4a")
        let audioFileURL2 = docDir.appendingPathComponent("\(numberOfRecords)_2.m4a")
        print("url 1", audioFileURL)
        print("url 2", audioFileURL2)
        
        //the shared audio session instance
        let audioSession = AVAudioSession.sharedInstance()
        do{
            //sets the category for recording and playback of audio
            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
        } catch {
            print("audio session error: \(error.localizedDescription)")
        }
        //recorder settings
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC), // audio codec
            AVSampleRateKey: 12000, // sample rate in hertz
            AVNumberOfChannelsKey: 1, //number of channels
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue // audio bit rate
        ]
        
        do {
            //create the AVAudioRecorder instance
            audioRecorder = try AVAudioRecorder(url: audioFileURL, settings: settings)
            audioRecorder?.prepareToRecord()
            audioRecorder2 = try AVAudioRecorder(url: audioFileURL2, settings: settings)
            audioRecorder2?.prepareToRecord()
            print("audio recorder ready")
        } catch {
            print("audio recorder error: \(error.localizedDescription)")
        }
    }
    @objc func loopSecondTrack() {
        if audioPlayer?.isPlaying == true {
            let timeCheck = audioPlayer!.deviceCurrentTime - self.deviceTime
            if abs(timeCheck - ((self.i-1.0) * audioPlayer!.duration + audioPlayer2!.duration)) < 0.05 {
                    audioPlayer2!.play(atTime: self.deviceTime + self.i*audioPlayer!.duration)
//                print("will play loop ", i)
                self.i += self.ratio
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

