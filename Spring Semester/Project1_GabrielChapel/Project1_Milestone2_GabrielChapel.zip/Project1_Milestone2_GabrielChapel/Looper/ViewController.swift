//
//  ViewController.swift
//  Looper
//
//  Created by Gabriel Chapel on 2/26/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var playButton2: UIButton!
    @IBOutlet weak var recordButton2: UIButton!
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?
    var audioPlayer2: AVAudioPlayer?
    var audioRecorder2: AVAudioRecorder?
    
    let fileName = "audio.m4a"
    let fileName2 = "audio2.m4a"
    
    @IBAction func changeVolume(_ sender: UISlider) {
        let volume = sender.value
        audioPlayer!.volume = volume
    }
    
    @IBAction func changeVolume2(_ sender: UISlider) {
        let volume2 = sender.value
        audioPlayer2!.volume = volume2
    }
    @IBAction func playAudio(_ sender: UIButton) {
        print("play audio 1")
        if audioRecorder?.isRecording == false{
            recordButton.isEnabled = false
            if audioPlayer?.isPlaying == false || audioPlayer?.isPlaying == nil{
            do{
                try audioPlayer = AVAudioPlayer(contentsOf: (audioRecorder?.url)!)
                audioPlayer!.numberOfLoops = -1
                audioPlayer!.delegate = self
                audioPlayer!.prepareToPlay()
                audioPlayer!.play()
                playButton.setImage(UIImage(named: "pauseButton"), for: .normal)
            } catch let error as NSError {
                print("audioPlayer error: \(error.localizedDescription)")
            }
            }else if audioPlayer?.isPlaying == true{
                recordButton.isEnabled = true
                audioPlayer!.pause()
                playButton.setImage(UIImage(named: "playButton"), for: .normal)
            }
        }
    }
    @IBAction func recordAudio(_ sender: UIButton) {
        print("record audio 1")
        if audioRecorder?.isRecording == false{
            playButton.isEnabled = false
            audioRecorder?.delegate = self
            audioRecorder?.record()
            recordButton.setImage(UIImage(named: "stopButton"), for: .normal)
        }else if audioRecorder?.isRecording == true{
            playButton.isEnabled = true
            audioRecorder?.stop()
            recordButton.setImage(UIImage(named: "recordButton"), for: .normal)
        }
    }
    
    @IBAction func playAudio2(_ sender: UIButton) {
        print("play audio 2")
        if audioRecorder2?.isRecording == false{
            recordButton2.isEnabled = false
            if audioPlayer2?.isPlaying == false || audioPlayer2?.isPlaying == nil{
                do{
                    try audioPlayer2 = AVAudioPlayer(contentsOf: (audioRecorder2?.url)!)
                    audioPlayer2!.numberOfLoops = -1
                    audioPlayer2!.delegate = self
                    audioPlayer2!.prepareToPlay()
                    audioPlayer2!.play()
                    playButton2.setImage(UIImage(named: "pauseButton"), for: .normal)
                } catch let error as NSError {
                    print("audioPlayer error: \(error.localizedDescription)")
                }
            }else if audioPlayer2?.isPlaying == true{
                recordButton2.isEnabled = true
                audioPlayer2!.pause()
                playButton2.setImage(UIImage(named: "playButton"), for: .normal)
                print("play audio 2 again")
            }
        }
    }
    @IBAction func recordAudio2(_ sender: UIButton) {
        print("record audio 2")
        if audioRecorder2?.isRecording == false{
            playButton2.isEnabled = false
            audioRecorder2?.delegate = self
            audioRecorder2?.record()
            recordButton2.setImage(UIImage(named: "stopButton"), for: .normal)
        }else if audioRecorder2?.isRecording == true{
            playButton2.isEnabled = true
            audioRecorder2?.stop()
            recordButton2.setImage(UIImage(named: "recordButton"), for: .normal)
        }
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        recordButton.isEnabled = true
        recordButton2.isEnabled = true
        playButton.setImage(UIImage(named: "playButton"), for: .normal)
        playButton2.setImage(UIImage(named: "playButton"), for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //disable button since no audio has been recorded
        playButton.isEnabled = false;
        playButton2.isEnabled = false;
        
        //get path for the audio file
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0]
        let audioFileURL = docDir.appendingPathComponent(fileName)
        let audioFileURL2 = docDir.appendingPathComponent(fileName2)
        print(audioFileURL)
        print(audioFileURL2)
        
        //the shared audio session instance
        let audioSession = AVAudioSession.sharedInstance()
        do{
            //sets the category for recording and playback of audio
            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
        } catch {
            print("audio session error: \(error.localizedDescription)")
        }
        //recorder settings
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC), // audio codec
            AVSampleRateKey: 12000, // sample rate in hertz
            AVNumberOfChannelsKey: 1, //number of channels
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue // audio bit rate
        ]
        
        do {
            //create the AVAudioRecorder instance
            audioRecorder = try AVAudioRecorder(url: audioFileURL, settings: settings)
            audioRecorder?.prepareToRecord()
            audioRecorder2 = try AVAudioRecorder(url: audioFileURL2, settings: settings)
            audioRecorder2?.prepareToRecord()
            print("audio recorder ready")
        } catch {
            print("audio recorder error: \(error.localizedDescription)")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

