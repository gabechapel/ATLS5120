package com.example.gabrielchapel.final_gabrielchapel;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class WorkoutCategoryActivity extends ListActivity{

    private String workoutType;
    private long workoutID;
    private int selectedIndex;
    private ArrayAdapter<String> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        workoutType = i.getStringExtra("workoutType");
        selectedIndex = i.getIntExtra("position", 0);
        //get list view
        ListView listWorkouts = getListView();
        //initialize array adapter with right list of workouts
        ArrayList<String> workoutList = new ArrayList<String>();
        workoutList = Workout.workouts[selectedIndex].getWorkout();
        listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, workoutList);
        listWorkouts.setAdapter(listAdapter);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.signup_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.signup:
                Intent intent = new Intent(this, SignupActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String workout = listAdapter.getItem(adapterContextMenuInfo.position);
        menu.setHeaderTitle("Delete" + workout);
        menu.add(1,1,1, "Yes");
        menu.add(2,2,2, "No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if(itemId == 1){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
            Workout.workouts[info.position].getWorkout().remove(info.position);
        }
        return true;
    }
}
