package com.example.gabrielchapel.final_gabrielchapel;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by gabrielchapel on 5/6/18.
 */

public class Workout {
    private String workoutType;
    private ArrayList<String> workout = new ArrayList<>();

    private Workout(String newWorkoutType, ArrayList<String> newWorkout){
        this.workoutType = newWorkoutType;
        this.workout = new ArrayList<String>(newWorkout);
    }

    public static final Workout[] workouts = {
            new Workout("Cardio", new ArrayList<String>(Arrays.asList("Running", "Swimming"))),
            new Workout("Strength", new ArrayList<String>(Arrays.asList("Weightlifting", "Climbing"))),
            new Workout("Flexibility", new ArrayList<String>(Arrays.asList("Yoga", "Ballet")))
    };

    public ArrayList<String> getWorkout(){
        return workout;
    }
    public String getWorkoutType(){
        return workoutType;
    }
    public String toString(){
        return this.workoutType;
    }
}
