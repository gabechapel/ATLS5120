package com.example.gabrielchapel.final_gabrielchapel;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;

public class SignupActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }
}
