//
//  Receipts.swift
//  GreenReceipt
//
//  Created by Tyler MIRONUCK on 4/14/18.
//  Copyright © 2018 Tyler MIRONUCK. All rights reserved.
//

import Foundation

class Receipts {
    var receiptsData = [[String : String]]()
    //var store = [String]()
    //var date = [String]()
    //var amount = [String]()
}
