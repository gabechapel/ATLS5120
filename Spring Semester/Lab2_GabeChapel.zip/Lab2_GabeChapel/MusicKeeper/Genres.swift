//
//  Genres.swift
//  MusicKeeper
//
//  Created by Gabriel Chapel on 2/17/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import Foundation

class Genres{
    var genreData = [String : [String]]()
    var genres = [String]()
}
