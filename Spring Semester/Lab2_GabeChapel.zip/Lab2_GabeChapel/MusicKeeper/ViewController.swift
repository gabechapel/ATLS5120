//
//  ViewController.swift
//  MusicKeeper
//
//  Created by Gabriel Chapel on 2/17/18.
//  Copyright © 2018 Gabriel Chapel. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var searchController : UISearchController!
    var genreList = Genres()
    let kfilename = "data1.plist"
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "artistsegue" {
            let detailVC = segue.destination as! DetailTableViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            //sets the data for the destination controller
            detailVC.title = genreList.genres[indexPath.row]
            detailVC.genreListDetail = genreList
            detailVC.selectedGenre = indexPath.row
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genreList.genres.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        cell.textLabel?.text = genreList.genres[indexPath.row]
        return cell
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        //enables large titles
        navigationController?.navigationBar.prefersLargeTitles = true
        
        // Change plist and name and check for persistent data
        let pathURL:URL?
        // get path for persistent data file
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0]
        //URL for persistent plist
        let dataFileURL = docDir.appendingPathComponent(kfilename)
        // use persistent data if it exists
        if FileManager.default.fileExists(atPath: dataFileURL.path){
            pathURL = dataFileURL
        } else{
            // if no persistent data
            pathURL = Bundle.main.url(forResource: "genres", withExtension: "plist")
        }
        // Create decoder and decode plist
        let plistdecoder = PropertyListDecoder()
        do {
            let data = try Data(contentsOf: pathURL!)
            genreList.genreData = try plistdecoder.decode([String: [String]].self, from: data)
            genreList.genres = Array(genreList.genreData.keys)
        } catch {
            print(error)
        }
        
        //application instance
        let app = UIApplication.shared
        //subscribe to the UIapplicationWillResignActiveNotification notification
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.applicationWillResignActive(_:)), name: NSNotification.Name.UIApplicationWillResignActive, object: app)
        
        //search results
        let resultsController = SearchResultsControllerTableViewController()
        resultsController.allwords = genreList.genres
        searchController = UISearchController(searchResultsController: resultsController)
        searchController.searchBar.placeholder = "Enter a search term"
        searchController.searchBar.sizeToFit()
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = resultsController
    }
    
    @objc func applicationWillResignActive(_ notification: NSNotification){
        //get path for data file
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0] //documents directory
        print(docDir)
        
        //URL for our plist
        let dataFileURL = docDir.appendingPathComponent(kfilename)
        print(dataFileURL)
        //creates a plist decoder object
        let plistencoder = PropertyListEncoder()
        plistencoder.outputFormat = .xml
        do {
            let data = try plistencoder.encode(genreList.genreData)
            try data.write(to: dataFileURL)
        } catch {
            print(error)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

