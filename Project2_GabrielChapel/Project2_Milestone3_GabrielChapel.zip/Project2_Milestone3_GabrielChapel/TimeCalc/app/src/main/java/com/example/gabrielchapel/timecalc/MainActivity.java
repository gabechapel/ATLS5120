package com.example.gabrielchapel.timecalc;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText startDate, startTime, endDate, endTime;
    TextView totalDaysLabel, totalHoursLabel, totalMinutesLabel, totalSecondsLabel;
    private int year, month, day, hour, minute, second, millisecond;
    private DatePickerDialog startDatePickerDialog, endDatePickerDialog;
    private TimePickerDialog startTimePickerDialog, endTimePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startDate = (EditText)findViewById(R.id.startDate);
        startDate.setInputType(InputType.TYPE_NULL);
        startTime = (EditText) findViewById(R.id.startTime);
        startTime.setInputType(InputType.TYPE_NULL);
        endDate = (EditText) findViewById(R.id.endDate);
        endDate.setInputType(InputType.TYPE_NULL);
        endTime = (EditText) findViewById(R.id.endTime);
        endTime.setInputType(InputType.TYPE_NULL);
        setTimeDate();
    }

    public void setTimeDate() {
        startDate.setOnClickListener(this);
        startTime.setOnClickListener(this);
        endDate.setOnClickListener(this);
        endTime.setOnClickListener(this);

        Calendar newCalendar = Calendar.getInstance();
        year = newCalendar.get(Calendar.YEAR);
        month = newCalendar.get(Calendar.MONTH);
        day = newCalendar.get(Calendar.DAY_OF_MONTH);
        hour = newCalendar.get(Calendar.HOUR_OF_DAY);
        minute = newCalendar.get(Calendar.MINUTE);
        second = newCalendar.get(Calendar.SECOND);
        // Dialog code was referenced from https://www.journaldev.com/9976/android-date-time-picker-dialog
        // and http://androidopentutorials.com/android-datepickerdialog-on-edittext-click-event/
        startDatePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int startyear, int startmonth, int startday) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(startyear, startmonth, startday);
                        String startyearString = String.valueOf(startyear);
                        String startmonthString = String.format(Locale.US, "%02d",startmonth + 1);
                        String startdayString = String.format(Locale.US, "%02d", startday);
                        startDate.setText(startyearString + "-" + startmonthString + "-" + startdayString);
                    }
                }, year, month, day);
        endDatePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int endyear, int endmonth, int endday) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(endyear, endmonth, endday);
                        String endyearString = String.valueOf(endyear);
                        String endmonthString = String.format(Locale.US, "%02d", endmonth + 1);
                        String enddayString = String.format(Locale.US, "%02d", endday);
                        endDate.setText(endyearString + "-" + endmonthString + "-" + enddayString);
                    }
                }, year, month, day);
        startTimePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int starthour, int startminute) {
                        Calendar newTime = Calendar.getInstance();
                        newTime.set(Calendar.HOUR, starthour);
                        newTime.set(Calendar.MINUTE, startminute);
                        String starthourString = String.format(Locale.US, "%02d", starthour);
                        String startminuteString = String.format(Locale.US, "%02d", startminute);
                        startTime.setText(starthourString + ":" + startminuteString);
                    }
                }, hour, minute, true);
        endTimePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int endhour, int endminute) {
                        Calendar newTime = Calendar.getInstance();
                        newTime.set(Calendar.HOUR, endhour);
                        newTime.set(Calendar.MINUTE, endminute);
                        String endhourString = String.format(Locale.US, "%02d", endhour);
                        String endminuteString = String.format(Locale.US, "%02d", endminute);
                        endTime.setText(endhourString + ":" + endminuteString);
                    }
                }, hour, minute, true);
    }

    @Override
    public void onClick(View view) {
        if (view == startDate) {
            startDatePickerDialog.show();
        } else if (view == endDate) {
            endDatePickerDialog.show();
        } else if (view == startTime) {
            startTimePickerDialog.show();
        } else if (view == endTime) {
            endTimePickerDialog.show();
        }
    }
    int daysInMonth(int month, int year){
        int numDays = 0;
        if ((month == 1) || (month == 3) || (month == 5) ||
                (month == 7) || (month == 8) || (month == 10) ||
                (month == 12)){
            numDays = 31;
        }else if (month == 2){
            numDays = 28 + leapYear(year);
        }else{
            numDays = 30;
        }
        return numDays;
    }
    int leapYear(int year){
        int leapDay = 0;
        if (((double)year/100.0) % 4 == 0){
            leapDay = 0;
        }else if (year % 4 == 0){
            leapDay = 1;
        }
        Log.d("year", Integer.toString(year));
        Log.d("remainder", Integer.toString(year % 4));
        Log.d("leapDay", Integer.toString(leapDay));
        return leapDay;
    }

    public void calculateTime(View view){
        String startTimeString = startTime.getText().toString();
        String startDateString = startDate.getText().toString();
        String endTimeString = endTime.getText().toString();
        String endDateString = endDate.getText().toString();
        if (startTimeString.length() != 5 || startDateString.length() != 10 ||
                endTimeString.length() != 5 || endDateString.length() != 10){
            Context context = getApplicationContext();
            Toast toast = Toast.makeText(context, "Please enter dates and times", Toast.LENGTH_LONG);
            toast.show();
        }else {
            String startHourString = startTimeString.substring(0, 2);
            String startminuteString = startTimeString.substring(3, 5);
            String startYearString = startDateString.substring(0, 4);
            String startMonthString = startDateString.substring(5, 7);
            String startDayString = startDateString.substring(8, 10);

            String endHourString = endTimeString.substring(0, 2);
            String endminuteString = endTimeString.substring(3, 5);
            String endYearString = endDateString.substring(0, 4);
            String endMonthString = endDateString.substring(5, 7);
            String endDayString = endDateString.substring(8, 10);

            int startHourInt = Integer.parseInt(startHourString);
            int startMinuteInt = Integer.parseInt(startminuteString);
            int startYearInt = Integer.parseInt(startYearString);
            int startMonthInt = Integer.parseInt(startMonthString);
            int startDayInt = Integer.parseInt(startDayString);

            int endHourInt = Integer.parseInt(endHourString);
            int endMinuteInt = Integer.parseInt(endminuteString);
            int endYearInt = Integer.parseInt(endYearString);
            int endMonthInt = Integer.parseInt(endMonthString);
            int endDayInt = Integer.parseInt(endDayString);
            // Check if the start and end times should be switched
            Boolean backwards = false;
            if (endYearInt < startYearInt){
                backwards = true;
            }else if (endYearInt == startYearInt){
                if (endMonthInt < startMonthInt){
                    backwards = true;
                }else if (endMonthInt == startMonthInt){
                    if (endDayInt < startDayInt) {
                        backwards = true;
                    } else if (endDayInt == startDayInt) {
                        if (endHourInt < startHourInt){
                            backwards = true;
                        }else if (endHourInt == startHourInt){
                            if (endMinuteInt < startMinuteInt){
                                backwards = true;
                            }
                        }
                    }
                }
            }
            if (backwards){
                int endYearTemp = endYearInt;
                int endMonthTemp = endMonthInt;
                int endDayTemp = endDayInt;
                int endHourTemp = endHourInt;
                int endMinuteTemp = endMinuteInt;
                endYearInt = startYearInt;
                endMonthInt = startMonthInt;
                endDayInt = startDayInt;
                endHourInt = startHourInt;
                endMinuteInt = startMinuteInt;
                startYearInt = endYearTemp;
                startMonthInt = endMonthTemp;
                startDayInt = endDayTemp;
                startHourInt = endHourTemp;
                startMinuteInt = endMinuteTemp;
                startTime.setText(endTimeString);
                startDate.setText(endDateString);
                endTime.setText(startTimeString);
                endDate.setText(startDateString);
            }

            int leapDays = 0;
            int yearDuration = endYearInt - startYearInt;
            if (yearDuration > 1) {
                for (int i = startYearInt + 1; i < endYearInt - 1; i++) {
                    leapDays += leapYear(i);
                }
            }
            if (startMonthInt > endMonthInt) {
                yearDuration -= 1;
            }

            int daysBetween = 0;
            int numStartDays = daysInMonth(startMonthInt, startYearInt);
            Log.d("monthDays", Integer.toString(numStartDays));
            if (startMonthInt == endMonthInt) {
                daysBetween = endDayInt - startDayInt;
            } else if (startMonthInt < endMonthInt) {
                for (int i = startMonthInt + 1; i < endMonthInt; i++) {
                    daysBetween += daysInMonth(i, startYearInt);
                    Log.d("daysBetween", Integer.toString(daysInMonth(i, startYearInt)));
                }
                daysBetween += (numStartDays - startDayInt + endDayInt);
                Log.d("day0", Integer.toString(daysBetween));
            } else {
                for (int i = startMonthInt + 1; i < 12; i++) {
                    daysBetween += daysInMonth(i, endYearInt);
                    Log.d("day1", Integer.toString(daysBetween));
                }
                for (int i = 1; i < endMonthInt; i++) {
                    if (startMonthInt > 2) {
                        daysBetween += daysInMonth(i, endYearInt);
                    } else {
                        daysBetween += daysInMonth(i, startYearInt);
                    }
                    Log.d("day2", Integer.toString(daysBetween));

                }
                daysBetween += (numStartDays - startDayInt + endDayInt);
                Log.d("day1", Integer.toString(daysBetween));

            }
            Log.d("daysBetween", Integer.toString(daysBetween));
            int dayDuration = daysBetween + 365 * yearDuration + leapDays;
            int hourDuration = endHourInt - startHourInt;
            int minuteDuration = endMinuteInt - startMinuteInt;
            if (minuteDuration < 0) {
                minuteDuration += 60;
                hourDuration -= 1;
            }
            int totalMinutes = minuteDuration + hourDuration * 60 + dayDuration * 24 * 60;
            int totalSeconds = totalMinutes * 60;
            double totalHours = totalMinutes / 60.0;
            double totalDays = totalHours / 24.0;
            totalDaysLabel = (TextView) findViewById(R.id.daysText);
            totalDaysLabel.setText(String.format(Locale.US, "%.4f", totalDays));
            totalHoursLabel = (TextView) findViewById(R.id.hoursText);
            totalHoursLabel.setText(String.format(Locale.US, "%.4f", totalHours));
            totalMinutesLabel = (TextView) findViewById(R.id.minutesText);
            totalMinutesLabel.setText(Integer.toString(totalMinutes));
            totalSecondsLabel = (TextView) findViewById(R.id.secondsText);
            totalSecondsLabel.setText(Integer.toString(totalSeconds));
        }



}
}