package com.example.gabrielchapel.cheapshots;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ReceiveLocationActivity extends AppCompatActivity {
    private String earlyLocation;
    private String earlyLocationURL;
    private String lateLocation;
    private String lateLocationURL;

    public void loadEarlyWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(earlyLocationURL));
        startActivity(intent);
    }

    public void loadLateWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(lateLocationURL));
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_location);

        Intent intent = getIntent();
        earlyLocation = intent.getStringExtra("earlyLocationName");
        earlyLocationURL = intent.getStringExtra("earlyLocationURL");
        lateLocation = intent.getStringExtra("lateLocationName");
        lateLocationURL = intent.getStringExtra("lateLocationURL");

        TextView earlyMessage = (TextView)findViewById(R.id.earlyLocationTextView);
        earlyMessage.setText("Check out " + earlyLocation + " for an early night");
        TextView lateMessage = (TextView)findViewById(R.id.lateLocationTextView);
        lateMessage.setText("Check out " + lateLocation + " for a late night");

        final Button earlyButton = (Button)findViewById(R.id.earlyButton);
        View.OnClickListener earlyOnClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadEarlyWebsite(view);
            }
        };
        earlyButton.setOnClickListener(earlyOnClick);

        final Button lateButton = (Button)findViewById(R.id.lateButton);
        View.OnClickListener lateOnClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadLateWebsite(view);
            }
        };
        lateButton.setOnClickListener(lateOnClick);
    }
}
