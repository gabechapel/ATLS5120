package com.example.gabrielchapel.cheapshots;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Locations location = new Locations();

    public void findLocation(View view){
        Spinner daySpinner = (Spinner)findViewById(R.id.spinner);
        Integer day = daySpinner.getSelectedItemPosition();
        location.setLocation(day);
        String earlyLocation = location.getEarlyLocation();
        String earlyLocationURL = location.getEarlyLocationURL();
        String lateLocation = location.getLateLocation();
        String lateLocationURL = location.getLateLocationURL();

        Intent intent = new Intent(this, ReceiveLocationActivity.class);
        intent.putExtra("earlyLocationName", earlyLocation);
        intent.putExtra("earlyLocationURL", earlyLocationURL);
        intent.putExtra("lateLocationName", lateLocation);
        intent.putExtra("lateLocationURL", lateLocationURL);

        startActivity(intent);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button)findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findLocation(view);
            }
        };
        button.setOnClickListener(onclick);
    }
}
