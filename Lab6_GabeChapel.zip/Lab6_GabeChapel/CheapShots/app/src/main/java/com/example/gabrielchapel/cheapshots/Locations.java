package com.example.gabrielchapel.cheapshots;

/**
 * Created by gabrielchapel on 12/1/17.
 */

public class Locations {
    private String earlyLocation;
    private String earlyLocationURL;
    private String lateLocation;
    private String lateLocationURL;

    private void setDrinkInfo(Integer dayOfWeek){
        switch(dayOfWeek){
            case 0: // Monday
                earlyLocation = "The Sink's Flip Night"; // $0.25 drinks for Flip Night
                earlyLocationURL = "https://thesink.com/";
                lateLocation = "Press Play's Panic hour"; // $0.25 drinks during Panic Hour
                lateLocationURL = "www.pressplaybar.com/";
                break;
            case 1: // Tuesday
                earlyLocation = "Bohemian Biergarten's $8 boots"; // $8 boots
                earlyLocationURL = "http://bohemianbiergarten.com/";
                lateLocation = "Dark Horse's Trike Night at 10pm"; // Trike Night at 10pm
                lateLocationURL = "http://darkhorsebar.com/";
                break;
            case 2: // Wednesday
                earlyLocation = "Walrus Saloon's Ladies Night"; // Women receive free drinks until midnight for Ladies Night
                earlyLocationURL = "http://boulderwalrus.com/";
                lateLocation = "Lazy Dog"; // $7 Bud Light pitchers
                lateLocationURL = "http://www.thelazydog.com/";
                break;
            case 3: // Thursday
                earlyLocation = "The Attic's $2 PBR all day"; // $2 PBR all day
                earlyLocationURL = "http://www.atticbistro.com/";
                lateLocation = "Half Fast's half off after 11:30pm"; // Half off 11:30pm - 1am
                lateLocationURL = "https://www.halffastsubs.com/";
                break;
            case 4: // Friday
                earlyLocation = "Taco Junky's Flight Night"; // $10 for 3 infused tequillas and 3 tacos
                earlyLocationURL = "http://tacojunky.com/";
                lateLocation = "Half Fast's half off after 11:30pm";
                lateLocationURL = "https://www.halffastsubs.com/";
                break;
            case 5: // Saturday
                earlyLocation = "Taco Junky's Sangria Saturday"; //$4 sangria for Sangria Saturday
                earlyLocationURL = "http://tacojunky.com/";
                lateLocation = "Half Fast's half off after 11:30pm";
                lateLocationURL = "https://www.halffastsubs.com/";
                break;
            case 6: // Sunday
                earlyLocation = "The Buff's $0.99 mimosas"; // $0.99 mimosas
                earlyLocationURL = "https://www.buffrestaurant.com/drinks";
                lateLocation = "this happy hour list";
                lateLocationURL = "http://www.therooster.com/happyhours/boulder";
                break;
            default:
                earlyLocation = "this happy hour list";
                earlyLocationURL = "http://www.therooster.com/happyhours/boulder";
                lateLocation = "this happy hour list";
                lateLocationURL = "http://www.therooster.com/happyhours/boulder";
                break;
        }
    }

    public void setLocation(Integer dayOfWeek){
        setDrinkInfo(dayOfWeek);
    }
    public void setLocationURL(Integer dayofWeek){
        setDrinkInfo(dayofWeek);
    }
    public String getEarlyLocation(){
        return earlyLocation;
    }
    public String getLateLocation(){
        return lateLocation;
    }
    public String getEarlyLocationURL(){
        return earlyLocationURL;
    }
    public String getLateLocationURL(){
        return lateLocationURL;
    }
}
