package com.example.gabrielchapel.timecalc;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText startDate, startTime, endDate, endTime;
    TextView totalDaysLabel, totalHoursLabel, totalMinutesLabel, totalSecondsLabel;
    private int year, month, day, hour, minute, second, millisecond;
    private DatePickerDialog startDatePickerDialog, endDatePickerDialog;
    private TimePickerDialog startTimePickerDialog, endTimePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startDate = (EditText)findViewById(R.id.startDate);
        startDate.setInputType(InputType.TYPE_NULL);
        startTime = (EditText) findViewById(R.id.startTime);
        startTime.setInputType(InputType.TYPE_NULL);
        endDate = (EditText) findViewById(R.id.endDate);
        endDate.setInputType(InputType.TYPE_NULL);
        endTime = (EditText) findViewById(R.id.endTime);
        endTime.setInputType(InputType.TYPE_NULL);
        setTimeDate();
    }

    public void setTimeDate() {
        startDate.setOnClickListener(this);
        startTime.setOnClickListener(this);
        endDate.setOnClickListener(this);
        endTime.setOnClickListener(this);

        Calendar newCalendar = Calendar.getInstance();
        year = newCalendar.get(Calendar.YEAR);
        month = newCalendar.get(Calendar.MONTH);
        day = newCalendar.get(Calendar.DAY_OF_MONTH);
        hour = newCalendar.get(Calendar.HOUR_OF_DAY);
        minute = newCalendar.get(Calendar.MINUTE);
        second = newCalendar.get(Calendar.SECOND);
        startDatePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int startyear, int startmonth, int startday) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(startyear, startmonth, startday);
                        String startyearString = String.valueOf(startyear);
                        String startmonthString = String.valueOf(startmonth + 1);
                        String startdayString = String.valueOf(startday);
                        if (startmonth < 10){
                            startmonthString = "0" + startmonthString;
                        }
                        if (startday < 10){
                            startdayString = "0" + startdayString;
                        }
                        startDate.setText(startyearString + "-" + startmonthString + "-" + startdayString);
                    }
                }, year, month, day);
        endDatePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int endyear, int endmonth, int endday) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(endyear, endmonth, endday);
                        String endyearString = String.valueOf(endyear);
                        String endmonthString = String.valueOf(endmonth + 1);
                        String enddayString = String.valueOf(endday);
                        if (endmonth < 10){
                            endmonthString = "0" + endmonthString;
                        }
                        if (endday < 10){
                            enddayString = "0" + enddayString;
                        }
                        endDate.setText(endyearString + "-" + endmonthString + "-" + enddayString);
                    }
                }, year, month, day);
        startTimePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int starthour, int startminute) {
                        Calendar newTime = Calendar.getInstance();
                        newTime.set(Calendar.HOUR, starthour);
                        newTime.set(Calendar.MINUTE, startminute);
                        String starthourString = String.valueOf(starthour);
                        String startminuteString = String.valueOf(startminute);
                        if (starthour < 10){
                            starthourString = "0" + starthourString;
                        }
                        if (startminute < 10){
                            startminuteString = "0" + startminuteString;
                        }
                        startTime.setText(starthourString + ":" + startminuteString);
                    }
                }, hour, minute, true);
        endTimePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int endhour, int endminute) {
                        Calendar newTime = Calendar.getInstance();
                        newTime.set(Calendar.HOUR, endhour);
                        newTime.set(Calendar.MINUTE, endminute);
                        String endhourString = String.valueOf(endhour);
                        String endminuteString = String.valueOf(endminute);
                        if (endhour < 10){
                            endhourString = "0" + endhourString;
                        }
                        if (endminute < 10){
                            endminuteString = "0" + endminuteString;
                        }
                        endTime.setText(endhourString + ":" + endminuteString);
                    }
                }, hour, minute, true);
    }

    @Override
    public void onClick(View view) {
        if (view == startDate) {
            startDatePickerDialog.show();
        } else if (view == endDate) {
            endDatePickerDialog.show();
        } else if (view == startTime) {
            startTimePickerDialog.show();
        } else if (view == endTime) {
            endTimePickerDialog.show();
        }
    }
    int daysInMonth(int month, int year){
        int numDays = 0;
        if ((month == 0) || (month == 2) || (month == 4) ||
                (month == 6) || (month == 7) || (month == 9) ||
                (month == 11)){
            numDays = 31;
        }else if (month == 1){
            numDays = 28 + leapYear(year);
        }else{
            numDays = 30;
        }
        return numDays;
    }
    int leapYear(int year){
        int leapDay = 0;
        if (year/100 % 4 == 0){
            leapDay = 0;
        }else if (year % 4 == 0){
            leapDay = 1;
        }
        return leapDay;
    }

    public void calculateTime(View view){
        TextView days = (TextView)findViewById(R.id.daysText);
        TextView hours = (TextView)findViewById(R.id.hoursText);
        TextView minutes = (TextView)findViewById(R.id.minutesText);
        TextView seconds = (TextView)findViewById(R.id.secondsText);
        String startTimeString = startTime.getText().toString();
        String startDateString = startDate.getText().toString();
        String startHourString = startTimeString.substring(0,1);
        String startminuteString = startTimeString.substring(3,4);
        String startYearString = startDateString.substring(0,3);
        String startMonthString = startDateString.substring(5,6);
        String startDayString = startDateString.substring(8,9);

        String endTimeString = endTime.getText().toString();
        String endDateString = endDate.getText().toString();
        String endHourString = endTimeString.substring(0,1);
        String endminuteString = endTimeString.substring(3,4);
        String endYearString = endDateString.substring(0,3);
        String endMonthString = endDateString.substring(5,6);
        String endDayString = endDateString.substring(8,9);

        int startHourInt = Integer.parseInt(startHourString);
        int startMinuteInt = Integer.parseInt(startminuteString);
        int startYearInt = Integer.parseInt(startYearString);
        int startMonthInt = Integer.parseInt(startMonthString);
        int startDayInt = Integer.parseInt(startDayString);

        int endHourInt = Integer.parseInt(endHourString);
        int endMinuteInt = Integer.parseInt(endminuteString);
        int endYearInt = Integer.parseInt(endYearString);
        int endMonthInt = Integer.parseInt(endMonthString);
        int endDayInt = Integer.parseInt(endDayString);

        int leapDays = 0;
        int yearDuration = endYearInt - startYearInt;
        if (yearDuration > 1){
            for (int i = startYearInt + 1; i < endYearInt - 1; i++){
                leapDays += leapYear(i);
            }
        }
        if (startMonthInt > endMonthInt){
            yearDuration -= 1;
        }

        int daysBetween = 0;
        if (startMonthInt == endMonthInt){
            daysBetween = endDayInt - startDayInt;
        }else if (startMonthInt < endMonthInt) {
            for (int i = startMonthInt + 1; i < endMonthInt; i++) {
                daysBetween += daysInMonth(i, startYearInt);
            }
        }else{
            for (int i = startMonthInt +1; i < 12; i++){
                daysBetween += daysInMonth(i, endYearInt);
            }
            for (int i = 0; i < endMonthInt; i++){
                daysBetween += daysInMonth(i, startYearInt);
            }
        }
        int numStartDays = daysInMonth(startMonthInt, startYearInt);
        int dayDuration = numStartDays - startDayInt + endDayInt + daysBetween+365*yearDuration + leapDays;
        int hourDuration = endHourInt - startHourInt;
        if (hourDuration < 0){
            hourDuration += 24;
        }else{
            dayDuration += 1;
        }
        int minuteDuration = endMinuteInt - startMinuteInt;
        if (minuteDuration < 0){
            minuteDuration += 60;
        }else{
            hourDuration += 1;
        }
        int totalMinutes = minuteDuration + hourDuration*60 + dayDuration*24*60;
        int totalSeconds = totalMinutes * 60;
        double totalHours = totalMinutes / 60.0;
        double totalDays = totalHours / 24.0;
        totalDaysLabel = (TextView)findViewById(R.id.daysText);
        totalDaysLabel.setText(Double.toString(totalDays));
        totalHoursLabel = (TextView)findViewById(R.id.hoursText);
        totalHoursLabel.setText(Double.toString(totalHours));
        totalMinutesLabel = (TextView)findViewById(R.id.minutesText);
        totalMinutesLabel.setText(totalMinutes);
        totalSecondsLabel = (TextView)findViewById(R.id.secondsText);
        totalSecondsLabel.setText(totalSeconds);



}
}