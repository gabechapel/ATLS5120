//
//  ViewController.swift
//  Coin_Toss
//
//  Created by Gabriel Chapel on 9/13/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import UIKit
var num : Int = 0
var choice : Int = 0

class ViewController: UIViewController {

    @IBOutlet weak var Response: UILabel!
    
    @IBAction func Heads_Tails(_ sender: UIButton) {
        let title = sender.title(for: .selected)!
        let text = "You Chose \(title)!"
        Response.text = text
        if title == "Heads" {
            choice = 1
        }
        else if title == "Tails" {
            choice = 2
        }
    }
    
    @IBOutlet weak var Coin: UIImageView!
    
    @IBAction func Toss(_ sender: UIButton) {
        num = Int(arc4random_uniform(2))
        let wrong = "You were wrong."
        let right = "You were right!"
        let none = "You did not guess"
        if num == 0 {
            Coin.image=UIImage(named: "Heads")
            if choice == 1{
                Response.text = right
            }
            else if choice == 2{
                Response.text = wrong
                }
            else if choice == 0{
                Response.text = none
            }
        }
        else if num == 1 {
            Coin.image=UIImage(named: "Tails")
            if choice == 1{
                Response.text = wrong
            }
            else if choice == 2{
                Response.text = right
            }
            else if choice == 0{
                Response.text = none
            }
        }
        choice = 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

