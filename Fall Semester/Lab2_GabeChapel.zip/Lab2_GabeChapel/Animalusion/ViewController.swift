//
//  ViewController.swift
//  Animalusion
//
//  Created by Gabriel Chapel on 9/14/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AnimalImage: UIImageView!
    @IBOutlet weak var AnimalLabel: UILabel!
    @IBOutlet weak var ImageControl: UISegmentedControl!
    @IBOutlet weak var capitalSwitch: UISwitch!
    @IBOutlet weak var fontSizeLabel: UILabel!
    
    func updateImage() {
        if ImageControl.selectedSegmentIndex==0 {
            AnimalLabel.text = "Doe-Elephant-Giraffe"
            AnimalImage.image = UIImage(named: "Animal_up")
        }
        else if ImageControl.selectedSegmentIndex==1 {
            AnimalLabel.text = "Seal-Swan-Penguin"
            AnimalImage.image = UIImage(named: "Animal_down")
        }
        
    }
    func updateCaps() {
        if capitalSwitch.isOn {
            AnimalLabel.text = AnimalLabel.text?.uppercased()
        }
        else {
            AnimalLabel.text = AnimalLabel.text?.lowercased()
        }
        
    }
    func updateColor() {
        if capitalSwitch.isOn {
            AnimalLabel.textColor = UIColor(red: 1, green: 0.7, blue: 0, alpha: 1)
        }
        else {
            AnimalLabel.textColor = UIColor(red: 0, green: 0.5, blue: 0, alpha: 1)
        }
    }
    
    @IBAction func changeImage(_ sender: UISegmentedControl) {
        updateImage()
        updateCaps()
            }
    
    @IBAction func updateFont(_ sender: UISwitch) {
        updateCaps()
        updateColor()
            }
    
    @IBAction func changeFontSize(_ sender: UISlider) {
        let fontSize = sender.value
        fontSizeLabel.text = String(format:"%.0f", fontSize)
        let fontSizeCGFloat = CGFloat(fontSize)
        AnimalLabel.font=UIFont.systemFont(ofSize: fontSizeCGFloat)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

