package com.example.gabrielchapel.sport;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findSport(View view) {
        // Toggle
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean location = toggle.isChecked();
        // Spinner
        Spinner exercise = (Spinner) findViewById(R.id.spinner);
        String exerciseType = String.valueOf(exercise.getSelectedItem());
        // Radio
        RadioGroup cost = (RadioGroup) findViewById(R.id.radioGroup);
        int cost_id = cost.getCheckedRadioButtonId();
        // Checkboxes
        CheckBox winterCheckBox = (CheckBox)findViewById(R.id.checkBox1);
        Boolean winter = winterCheckBox.isChecked();
        CheckBox springCheckBox = (CheckBox)findViewById(R.id.checkBox2);
        Boolean spring = springCheckBox.isChecked();
        CheckBox summerCheckBox = (CheckBox)findViewById(R.id.checkBox3);
        Boolean summer = summerCheckBox.isChecked();
        CheckBox fallCheckBox = (CheckBox)findViewById(R.id.checkBox4);
        Boolean fall = fallCheckBox.isChecked();
        // Images
        ImageView image = (ImageView)findViewById(R.id.imageView);
        if(winter) {
            image.setImageResource(R.drawable.winter);
        } else if(spring) {
            image.setImageResource(R.drawable.spring);
        } else if(summer) {
            image.setImageResource(R.drawable.summer);
        } else if(fall) {
            image.setImageResource(R.drawable.fall);
        }
        String perfectSport;
        if (cost_id == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a cost level";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (location) {//inside
                perfectSport = "Fight club";
                switch (cost_id) {
                    case R.id.radioButton1: // $
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = "Fight club";
                                break;
                            case "strength":
                                perfectSport = "Dodgeball";
                                break;
                            case "flexibility":
                                perfectSport = "Stretching";
                                break;
                            default:
                                perfectSport = "Fight club";
                        }
                        break;
                    case R.id.radioButton2: // $$
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = "Ping pong";
                                break;
                            case "strength":
                                perfectSport = "Weight lifting";
                                break;
                            case "flexibility":
                                perfectSport = "Yoga";
                                break;
                            default:
                                perfectSport = "Ping pong";
                        }
                        break;
                    case R.id.radioButton3: // $$$
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = "Spin class";
                                break;
                            case "strength":
                                perfectSport = "Pool";
                                break;
                            case "flexibility":
                                perfectSport = "Yoga class";
                                break;
                            default:
                                perfectSport = "Spin class";
                        }
                        break;
                }
            } else {//outside
                String cardioSport;
                String strengthSport;
                String flexSport;
                perfectSport = "Running";
                switch (cost_id) {
                    case R.id.radioButton1: // $
                        if(winter) {
                            cardioSport = "Shoveling";
                            strengthSport = "Shoveling";
                            flexSport = "Shoveling";
                        } else if(spring) {
                            cardioSport = "Soccer";
                            strengthSport = "Hiking";
                            flexSport = "Stretching";
                        } else if(summer) {
                            cardioSport = "Swimming";
                            strengthSport = "Volleyball";
                            flexSport = "Stretching";
                        } else {
                            cardioSport = "Running";
                            strengthSport = "Hiking";
                            flexSport = "Stretching";
                        }
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = cardioSport;
                                break;
                            case "strength":
                                perfectSport = strengthSport;
                                break;
                            case "flexibility":
                                perfectSport = flexSport;
                                break;
                            default:
                                perfectSport = "Hiking";
                        }
                        break;
                    case R.id.radioButton2: // $$
                        if(winter) {
                            cardioSport = "Snow shoeing";
                            strengthSport = "Hockey";
                            flexSport = "Figure skating";
                        } else if(spring) {
                            cardioSport = "Skateboarding";
                            strengthSport = "Backpacking";
                            flexSport = "Kayaking";
                        } else if(summer) {
                            cardioSport = "Skateboarding";
                            strengthSport = "Backpacking";
                            flexSport = "Yoga";
                        } else {
                            cardioSport = "Basketball";
                            strengthSport = "Backpacking";
                            flexSport = "Yoga";
                        }
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = cardioSport;
                                break;
                            case "strength":
                                perfectSport = strengthSport;
                                break;
                            case "flexibility":
                                perfectSport = flexSport;
                                break;
                            default:
                                perfectSport = "Backpacking";
                        }
                        break;
                    case R.id.radioButton3: // $$$
                        if(winter) {
                            cardioSport = "Skiing";
                            strengthSport = "Ice climbing";
                            flexSport = "Skiing";
                        } else if(spring) {
                            cardioSport = "Biking";
                            strengthSport = "Climbing";
                            flexSport = "Goat yoga";
                        } else if(summer) {
                            cardioSport = "Jet skiing";
                            strengthSport = "NASCAR";
                            flexSport = "Wake boarding";
                        } else {
                            cardioSport = "Biking";
                            strengthSport = "Climbing";
                            flexSport = "Goat yoga";
                        }
                        switch (exerciseType) {
                            case "cardio":
                                perfectSport = cardioSport;
                                break;
                            case "strength":
                                perfectSport = strengthSport;
                                break;
                            case "flexibility":
                                perfectSport = flexSport;
                                break;
                            default:
                                perfectSport = "Climbing";
                        }
                        break;
                }
            }
            TextView sportSelection = (TextView) findViewById(R.id.sportTextView);
            sportSelection.setText(perfectSport + " is the sport for you");
        }
    }
}
