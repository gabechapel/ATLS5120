//
//  HighScore.swift
//  Yahtzee
//
//  Created by Tyler MIRONUCK on 12/3/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import Foundation

class HighScore {
    var highScore : String?
}
