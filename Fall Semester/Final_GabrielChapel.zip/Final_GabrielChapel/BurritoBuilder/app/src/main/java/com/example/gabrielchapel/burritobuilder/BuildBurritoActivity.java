package com.example.gabrielchapel.burritobuilder;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class BuildBurritoActivity extends AppCompatActivity {
    private BurritoShop myBurritoShop = new BurritoShop();

    public void buildBurrito(View view){
        EditText name = (EditText)findViewById(R.id.editText);
        String burritoName = name.getText().toString();

        ToggleButton toggle = (ToggleButton)findViewById(R.id.toggleButton);
        String burritoType = String.valueOf(toggle.getText());

        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        String location = String.valueOf(spinner.getSelectedItem());

        RadioGroup group = (RadioGroup)findViewById(R.id.radioGroup);
        int group_id = group.getCheckedRadioButtonId();
        String choice;

        if (group_id == -1){
            Context context = getApplicationContext();
            CharSequence text = "Please select either a burrito or taco";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            return;
        }else if(group_id == 0){
            choice = "burrito";
        }else{
            choice = "taco";
        }

        CheckBox salsaBox = (CheckBox)findViewById(R.id.checkBox1);
        Boolean salsaCheck = salsaBox.isChecked();
        String salsa;

        CheckBox sourcreamBox = (CheckBox)findViewById(R.id.checkBox2);
        Boolean sourcreamCheck = sourcreamBox.isChecked();
        String sourcream;

        CheckBox cheeseBox = (CheckBox)findViewById(R.id.checkBox3);
        Boolean cheeseCheck = cheeseBox.isChecked();
        String cheese;

        CheckBox guacBox = (CheckBox)findViewById(R.id.checkBox4);
        Boolean guacCheck = guacBox.isChecked();
        String guac;

        if(salsaCheck){
            salsa = "salsa ";
        }else{
            salsa = "";
        }
        if(sourcreamCheck){
            sourcream = "sour cream ";
        }else{
            sourcream = "";
        }
        if(cheeseCheck){
            cheese = "cheese ";
        }else{
            cheese = "";
        }
        if(guacCheck){
            guac = "guacamole ";
        }else{
            guac = "";
        }

        TextView yourBurrito = (TextView)findViewById(R.id.yourBurrito);
        yourBurrito.setText("The " + burritoName + " is a " + burritoType + " " + choice + " with " + salsa + sourcream +
        cheese + guac + "that you can eat on " + location);
    }

    public void findBurrito(View view){
        Spinner locationSpinner = (Spinner)findViewById(R.id.spinner);
        Integer location = locationSpinner.getSelectedItemPosition();
        myBurritoShop.setBurritoShop(location);
        String suggestedBurritoShop = myBurritoShop.getBurritoShop();
        String suggestedBurritoShopURL = myBurritoShop.getBurritoShopURL();

        Intent intent = new Intent(this, ReceiveBurritoActivity.class);
        intent.putExtra("burritoShopName", suggestedBurritoShop);
        intent.putExtra("burritoShopURL", suggestedBurritoShopURL);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_build_burrito);
    }
}
