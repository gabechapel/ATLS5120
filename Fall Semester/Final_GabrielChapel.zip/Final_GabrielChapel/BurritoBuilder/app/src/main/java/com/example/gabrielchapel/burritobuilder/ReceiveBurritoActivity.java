package com.example.gabrielchapel.burritobuilder;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ReceiveBurritoActivity extends AppCompatActivity {
    private String burritoShop;
    private String burritoShopURL;

    public void loadWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(burritoShopURL));
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_burrito);

        Intent intent = getIntent();
        burritoShop = intent.getStringExtra("burritoShopName");
        burritoShopURL = intent.getStringExtra("burritoShopURL");

        TextView messageView = (TextView)findViewById(R.id.suggestedLocation);
        messageView.setText("You should check out " + burritoShop);

    }
}
