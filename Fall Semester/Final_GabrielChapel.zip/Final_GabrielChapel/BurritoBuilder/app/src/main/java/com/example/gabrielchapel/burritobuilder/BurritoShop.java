package com.example.gabrielchapel.burritobuilder;

/**
 * Created by gabrielchapel on 12/17/17.
 */

public class BurritoShop {
    private String burritoShop;
    private String burritoShopURL;

    private void setBurritoInfo(Integer location){
        switch(location){
            case 0:
                burritoShop = "Illegal Petes";
                burritoShopURL = "https://illegalpetes.com";
                break;
            case 1:
                burritoShop = "Chipotle";
                burritoShopURL = "https://www.chipotle.com/";
                break;
            case 2:
                burritoShop = "Bartaco";
                burritoShopURL = "https://bartaco.com/";
                break;
            default:
                burritoShop = "none";
                burritoShopURL = "https://www.google.com/search?q=boulder+burritos&oq=boulder+burritos&aqs=chrome..69i57j0l5.6230j0j7&sourceid=chrome&ie=UTF-8";
                break;
        }
    }
    public void setBurritoShop(Integer location){
        setBurritoInfo(location);
    }
    public void setBurritoShopURL(Integer location){
        setBurritoInfo(location);
    }
    public String getBurritoShop(){
        return burritoShop;
    }
    public String getBurritoShopURL(){
        return burritoShopURL;
    }
}
