//
//  ViewController.swift
//  ShoppingCart
//
//  Created by Gabriel Chapel on 10/12/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var oneLabel: UILabel!
    @IBOutlet weak var twoLabel: UILabel!
    @IBOutlet weak var threeLabel: UILabel!
    @IBOutlet weak var fourLabel: UILabel!
    @IBOutlet weak var fiveLabel: UILabel!
    
    var user=Cart()
    let filename = "cart.plist"
    
    func docFilePath(_ filename: String) -> String?{
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
        let dir = path[0] as NSString
        return dir.appendingPathComponent(filename)
    }
    
    func applicationWillResignActive(_ notification: Notification){
        let filePath = docFilePath(filename)
        let data = NSMutableDictionary()
        if user.numOne != nil{
            data.setValue(user.numOne, forKey: "one")
        }
        if user.numTwo != nil{
            data.setValue(user.numTwo, forKey: "two")
        }
        if user.numThree != nil{
            data.setValue(user.numThree, forKey: "three")
        }
        if user.numFour != nil{
            data.setValue(user.numFour, forKey: "four")
        }
        if user.numFive != nil{
            data.setValue(user.numFive, forKey: "five")
        }
        data.write(toFile: filePath!, atomically: true)
    }
    
    @IBAction func unwindSegue(_ segue: UIStoryboardSegue) {
        oneLabel.text=user.numOne
        twoLabel.text=user.numTwo
        threeLabel.text=user.numThree
        fourLabel.text=user.numFour
        fiveLabel.text=user.numFive
    }
    override func viewDidLoad() {
        let filePath = docFilePath(filename)
        if FileManager.default.fileExists(atPath: filePath!){
            let path = filePath
            let dataDictionary = NSDictionary(contentsOfFile: path!) as! [String:String]
            if dataDictionary.keys.contains("one"){
                user.numOne = dataDictionary["one"]
                oneLabel.text=user.numOne
            }
            if dataDictionary.keys.contains("two"){
                user.numTwo = dataDictionary["two"]
                twoLabel.text=user.numTwo
            }
            if dataDictionary.keys.contains("three"){
                user.numThree = dataDictionary["three"]
                threeLabel.text=user.numThree
            }
            if dataDictionary.keys.contains("four"){
                user.numFour = dataDictionary["four"]
                fourLabel.text=user.numFour
            }
            if dataDictionary.keys.contains("five"){
                user.numFive = dataDictionary["five"]
                fiveLabel.text=user.numFive
            }
        }
        let app = UIApplication.shared
        NotificationCenter.default.addObserver(self, selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)), name: NSNotification.Name(rawValue: "UIApplicationWillResignActiveNotification"), object:app)
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

