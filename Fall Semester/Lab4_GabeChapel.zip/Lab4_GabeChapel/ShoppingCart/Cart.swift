//
//  Cart.swift
//  ShoppingCart
//
//  Created by Gabriel Chapel on 10/14/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import Foundation

class Cart {
    var numOne : String?
    var numTwo : String?
    var numThree : String?
    var numFour : String?
    var numFive : String?
}
