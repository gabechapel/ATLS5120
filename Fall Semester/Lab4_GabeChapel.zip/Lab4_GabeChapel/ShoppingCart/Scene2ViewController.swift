//
//  Scene2ViewController.swift
//  ShoppingCart
//
//  Created by Gabriel Chapel on 10/12/17.
//  Copyright © 2017 Gabriel Chapel. All rights reserved.
//

import UIKit

class Scene2ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var userOne: UITextField!
    @IBOutlet weak var userTwo: UITextField!
    @IBOutlet weak var userThree: UITextField!
    @IBOutlet weak var userFour: UITextField!
    @IBOutlet weak var userFive: UITextField!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneCart"{
            let scene1ViewController = segue.destination as! ViewController
            if userOne.text!.isEmpty == false{
                scene1ViewController.user.numOne = userOne.text
            }
            if userTwo.text!.isEmpty == false{
                scene1ViewController.user.numTwo=userTwo.text
            }
            if userThree.text!.isEmpty == false{
                scene1ViewController.user.numThree = userThree.text
            }
            if userFour.text!.isEmpty == false{
                scene1ViewController.user.numFour=userFour.text
            }
            if userFive.text!.isEmpty == false{
                scene1ViewController.user.numFive=userFive.text
            }
        }
    }
    
    override func viewDidLoad() {
        userOne.delegate=self
        userTwo.delegate=self
        userThree.delegate=self
        userFour.delegate=self
        userFive.delegate=self
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
